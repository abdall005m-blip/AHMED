package com.nexus.personaldashboard.ui.screens.entertainment

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.nexus.personaldashboard.ui.components.SectionBackground
import com.nexus.personaldashboard.ui.navigation.NavRoute

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EntertainmentScreen(onNavigate: (NavRoute) -> Unit, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        SectionBackground(section = "entertainment")
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            TopAppBar(
                title = { Text("Entertainment 🎮", fontWeight = FontWeight.Bold) },
                navigationIcon = { IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, null) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
            Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    EntertainmentCard("💬", "الشات الخاص", "Private Chat", listOf(Color(0xFFEC4899), Color(0xFFBE185D)), Modifier.weight(1f)) { onNavigate(NavRoute.PRIVATE_CHAT) }
                    EntertainmentCard("🎮", "الألعاب", "Games", listOf(Color(0xFF7C3AED), Color(0xFF4F46E5)), Modifier.weight(1f)) { onNavigate(NavRoute.GAMES) }
                }
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    EntertainmentCard("💖", "المزاج", "My Mood", listOf(Color(0xFFF59E0B), Color(0xFFD97706)), Modifier.weight(1f)) { onNavigate(NavRoute.MOOD) }
                    EntertainmentCard("🕌", "إسلامي", "Islamic", listOf(Color(0xFF059669), Color(0xFF047857)), Modifier.weight(1f)) { onNavigate(NavRoute.ISLAMIC) }
                }
            }
        }
    }
}

@Composable
fun EntertainmentCard(emoji: String, titleAr: String, titleEn: String, gradient: List<Color>, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier = modifier
            .fillMaxHeight()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.linearGradient(gradient))
            .clickable(onClick = onClick)
            .padding(20.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Text(emoji, fontSize = 40.sp)
            Column {
                Text(titleAr, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White)
                Text(titleEn, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(.8f))
            }
        }
    }
}
